﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using sxlib.Specialized;

namespace Side_SynX
{
    class Stuff
    {
        //add the sxlib reference before doing anything!!!
        public static SxLibWinForms Lib;
    }
}
